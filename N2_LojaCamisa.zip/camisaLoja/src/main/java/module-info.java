module com.example.camisaloja {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;
    requires org.postgresql.jdbc;


    opens fxml to javafx.fxml;


    opens com.example.camisaloja.controller to javafx.fxml;
    opens com.example.camisaloja.dao to javafx.fxml;
    opens com.example.camisaloja.model to javafx.fxml;

    exports com.example.camisaloja.controller;
    exports com.example.camisaloja.dao;
    exports com.example.camisaloja.model;
    exports com.example.camisaloja.view;
    opens com.example.camisaloja.view to javafx.fxml;
}