package com.example.camisaloja.controller;

import com.example.camisaloja.dao.CamisaDao;
import com.example.camisaloja.dao.CompraDao;
import com.example.camisaloja.dao.FornecedorDao;
import com.example.camisaloja.model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CompraController implements Initializable {

    private CompraDao compraDao = new CompraDao();
    private CamisaDao camisaDao = new CamisaDao();
    private FornecedorDao fornecedorDao = new FornecedorDao();

    @FXML
    private ListView<Compra> LstCompra;

    @FXML
    private Button BtnInserir;

    @FXML
    private Button BtnGravar;

    @FXML
    private Button BtnCancelar;

    @FXML
    private TextField TxtCodigo;

    @FXML
    private TextField TxtData;

    @FXML
    private TextField TxtQuantidade;

    @FXML
    private ComboBox<Camisa> CboCamisa;

    @FXML
    private ComboBox<Fornecedor> CboFornecedor;

    //= Métodos auxiliares =//

    private void habilitarInterface(boolean valor){
        CboCamisa.setDisable(!valor);
        CboFornecedor.setDisable(!valor);
        TxtQuantidade.setDisable(!valor);

        BtnInserir.setDisable(valor);
        BtnCancelar.setDisable(!valor);
        BtnGravar.setDisable(!valor);
        LstCompra.setDisable(valor);
    }

    private void limparInterface(){
        TxtCodigo.setText("");
        TxtData.setText("");
        TxtQuantidade.setText("");
        CboCamisa.setValue(null);
        CboFornecedor.setValue(null);
    }

    private void atualizarLista(){
        List<Compra> compras;
        try{
            compras = compraDao.listar();
        } catch(Exception e) {
            compras = new ArrayList<Compra>();
            e.printStackTrace();
        }
        ObservableList<Compra> comprasOb = FXCollections.observableArrayList(compras);
        LstCompra.setItems(comprasOb);
    }

    //= Metodos Lst e Cliente =//

    private void exiblirCompras(){
        Compra comprass = LstCompra.getSelectionModel().getSelectedItem();

        if (comprass == null) return;
        TxtData.setText(comprass.getDataCompra().toString());
        TxtCodigo.setText(comprass.getCodCompra().toString());
        CboCamisa.setValue(comprass.getCamisaa());
        CboFornecedor.setValue(comprass.getFornecedorr());

        // Incerto/Errado:
        //Camisa camisa = new Camisa();
        //TxtQuantidade.setText(camisa.getQtdEstoque().toString());
    }

    @FXML
    private void LstCompra_MouseClicked(MouseEvent evento){
        exiblirCompras();
    }

    @FXML
    private void LstCompra_KeyPressed(KeyEvent evento){
        exiblirCompras();
    }

    //= Botões =//

    @FXML
    protected void BtnInserir_Action(ActionEvent evento){
        CboCamisa.requestFocus();
        habilitarInterface(true);
        limparInterface();
    }

    @FXML
    protected void BtnCancelar_Action(ActionEvent evento){
        limparInterface();
        habilitarInterface(false);
    }


    @FXML
    protected void BtnGravar_Action(ActionEvent evento){
        Compra compra = new Compra();
        Camisa camisa = CboCamisa.getValue();
        DetalheCompra detalheCompra = new DetalheCompra();

        detalheCompra.setCamisa(CboCamisa.getValue());
        detalheCompra.setQuantidade(Double.parseDouble(TxtQuantidade.getText()));
        detalheCompra.setPrecoTotal(detalheCompra.getQuantidade()*camisa.getPreco()*0.75);

        compra.setCamisaa(camisa);
        compra.setDataCompra(LocalDate.now());
        compra.setFornecedorr(CboFornecedor.getValue());
        compra.setDetalheCompra(detalheCompra);

        try {
            compraDao.gravar(compra);
            camisaDao.gravar(camisa);
        } catch (Exception e){
            e.printStackTrace();
        }
        atualizarLista();
        habilitarInterface(false);
    }

    //---//
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        atualizarLista();

        List<Camisa> camisaaas;
        List<Fornecedor> fornecedors;

        try {
            camisaaas = camisaDao.listar();
            fornecedors = fornecedorDao.listar();
        } catch (Exception e) {
            camisaaas = new ArrayList<Camisa>();
            fornecedors = new ArrayList<>();
        }

        ObservableList<Camisa> camisaOb = FXCollections.observableArrayList(camisaaas);
        CboCamisa.setItems(camisaOb);

        ObservableList<Fornecedor> fornecedorsOb = FXCollections.observableArrayList(fornecedors);
        CboFornecedor.setItems(fornecedorsOb);
    }
}
