package com.example.camisaloja.controller;

import com.example.camisaloja.dao.TimeeDao;
import com.example.camisaloja.model.Timee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import javafx.event.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class TimeeController implements Initializable {

    private TimeeDao timeeDao = new TimeeDao();

    @FXML
    private ListView<Timee> LstTimee;

    @FXML
    private Button BtnInserir;

    @FXML
    private Button BtnGravar;

    @FXML
    private Button BtnCancelar;

    @FXML
    private TextField TxtNome;

    @FXML
    private TextField TxtId;


    //= Métodos auxiliares =//

    private void habilitarInterface(boolean valor){
        TxtNome.setDisable(!valor);

        BtnInserir.setDisable(valor);
        BtnCancelar.setDisable(!valor);
        BtnGravar.setDisable(!valor);
        LstTimee.setDisable(valor);
    }

    private void limparInterface(){
        TxtNome.setText("");
        TxtId.setText("");
    }

    private void atualizarLista(){
        List<Timee> timees;
        try{
            timees = timeeDao.listar();
        } catch(Exception e) {
            timees = new ArrayList<Timee>();
        }
        ObservableList<Timee> timeesOb = FXCollections.observableArrayList(timees);
        LstTimee.setItems(timeesOb);
    }

    //= Metodos Lst e Cliente =//

    private void exiblirTimees(){
        Timee timeess = LstTimee.getSelectionModel().getSelectedItem();
        if (timeess == null) return;

        TxtNome.setText(timeess.getNome());
        TxtId.setText(timeess.getId().toString());
    }

    @FXML
    private void LstTimee_MouseClicked(MouseEvent evento){
        exiblirTimees();
    }

    @FXML
    private void LstTimee_KeyPressed(KeyEvent evento){
        exiblirTimees();
    }

    //= Botões =//

    @FXML
    protected void BtnInserir_Action(ActionEvent evento){
        TxtNome.requestFocus();
        habilitarInterface(true);
        limparInterface();
    }

    @FXML
    protected void BtnCancelar_Action(ActionEvent evento){
        limparInterface();
        habilitarInterface(false);
    }

    @FXML
    protected void BtnGravar_Action(ActionEvent evento){
        Timee timee = new Timee();
        timee.setNome(TxtNome.getText());

        try {
            timeeDao.gravar(timee);
        } catch (Exception e){
            e.printStackTrace();
        }
        atualizarLista();
        habilitarInterface(false);
    }

    //---//
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        atualizarLista();
    }
}
