package com.example.camisaloja.controller;

import com.example.camisaloja.dao.*;
import com.example.camisaloja.model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class VendaController implements Initializable {

    private VendaDao vendaDao = new VendaDao();
    private CamisaDao camisaDao = new CamisaDao();
    private ClienteDao clienteDao = new ClienteDao();

    @FXML
    private ListView<Venda> LstVenda;

    @FXML
    private Button BtnInserir;

    @FXML
    private Button BtnGravar;

    @FXML
    private Button BtnCancelar;

    @FXML
    private TextField TxtCodigo;

    @FXML
    private TextField TxtData;

    @FXML
    private TextField TxtQuantidade;

    @FXML
    private ComboBox<Camisa> CboCamisa;

    @FXML
    private ComboBox<Cliente> CboCliente;

    //= Métodos auxiliares =//

    private void habilitarInterface(boolean valor){
        CboCamisa.setDisable(!valor);
        CboCliente.setDisable(!valor);
        TxtQuantidade.setDisable(!valor);

        BtnInserir.setDisable(valor);
        BtnCancelar.setDisable(!valor);
        BtnGravar.setDisable(!valor);
        LstVenda.setDisable(valor);
    }

    private void limparInterface(){
        TxtCodigo.setText("");
        TxtData.setText("");
        TxtQuantidade.setText("");
        CboCamisa.setValue(null);
        CboCliente.setValue(null);
    }

    private void atualizarLista(){
        List<Venda> vendas;
        try{
            vendas = vendaDao.listar();
        } catch(Exception e) {
            vendas = new ArrayList<Venda>();
        }
        ObservableList<Venda> vendasOb = FXCollections.observableArrayList(vendas);
        LstVenda.setItems(vendasOb);
    }

    private void exiblirCompras(){
        Venda vendass = LstVenda.getSelectionModel().getSelectedItem();


        if (vendass == null) return;
        TxtData.setText(vendass.getDataVenda().toString());
        TxtCodigo.setText(vendass.getCodVenda().toString());
        CboCamisa.setValue(vendass.getCamisaa());
        CboCliente.setValue(vendass.getClientee());

        // Incerto/Errado:
        //Camisa camisa = new Camisa();
        //TxtQuantidade.setText(camisa.getQtdEstoque().toString());
    }

    @FXML
    private void LstVenda_MouseClicked(MouseEvent evento){
        exiblirCompras();
    }

    @FXML
    private void LstVenda_KeyPressed(KeyEvent evento){
        exiblirCompras();
    }

    //= Botões =//

    @FXML
    protected void BtnInserir_Action(ActionEvent evento){
        CboCamisa.requestFocus();
        habilitarInterface(true);
        limparInterface();
    }

    @FXML
    protected void BtnCancelar_Action(ActionEvent evento){
        limparInterface();
        habilitarInterface(false);
    }


    @FXML
    protected void BtnGravar_Action(ActionEvent evento){
        Venda venda = new Venda();
        Camisa camisa = CboCamisa.getValue();
        DetalheVenda detalheVenda = new DetalheVenda();

        detalheVenda.setCamisa(CboCamisa.getValue());
        detalheVenda.setQuantidade(Double.parseDouble(TxtQuantidade.getText()));
        detalheVenda.setPrecoTotal(detalheVenda.getQuantidade()*camisa.getPreco());

        venda.setCamisaa(camisa);
        venda.setDataVenda(LocalDate.now());
        venda.setClientee(CboCliente.getValue());
        venda.setDetalheVenda(detalheVenda);

        try {
            vendaDao.gravar(venda);
            camisaDao.gravar(camisa);
        } catch (Exception e){
            e.printStackTrace();
        }
        atualizarLista();
        habilitarInterface(false);
    }

    //---//
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        atualizarLista();

        List<Camisa> camisaaas;
        List<Cliente> clientes;

        try {
            camisaaas = camisaDao.listar();
            clientes = clienteDao.listar();
        } catch (Exception e) {
            camisaaas = new ArrayList<Camisa>();
            clientes = new ArrayList<>();
        }

        ObservableList<Camisa> camisaOb = FXCollections.observableArrayList(camisaaas);
        CboCamisa.setItems(camisaOb);

        ObservableList<Cliente> clienteOb = FXCollections.observableArrayList(clientes);
        CboCliente.setItems(clienteOb);
    }
}
