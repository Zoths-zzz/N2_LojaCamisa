package com.example.camisaloja.dao;

import java.sql.*;

public abstract class DaoPostgres {
    protected static String ENDERECO = "localhost";
    protected static String BD = "lojacamisafutebol";
    protected static String PORTA = "5432";
    protected static String USUARIO = "postgres";
    protected static String SENHA = "postgres";

    protected Connection getConexao() throws SQLException {
        String url = "jdbc:postgresql://" + ENDERECO + ":" + PORTA + "/" + BD;
        Connection con = DriverManager.getConnection(url, USUARIO, SENHA);
        return con;
    }

    protected PreparedStatement getPreparedStatement(String sql, Boolean insercao) throws Exception {
        PreparedStatement ps = null;
        if (insercao) {
            return getConexao().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        } else {
            return getConexao().prepareStatement(sql);
        }
    }



}
