package com.example.camisaloja.model;

public enum Medidas {
    PP("PP"),
    P  ("P"),
    M  ("M"),
    G  ("G"),
    GG("GG");

    private String medida;

    Medidas(String medidaa){
        this.medida = medidaa;
    }

    public static Medidas getMedidaById(Integer id){
        if (id.equals(1)) return Medidas.PP;
        if (id.equals(2)) return Medidas.P;
        if (id.equals(3)) return Medidas.M;
        if (id.equals(4)) return Medidas.G;
        if (id.equals(5)) return Medidas.GG;

        return Medidas.M;
    }

    public static Integer GetIdByMedida(Medidas medidas){
        if(medidas == Medidas.PP) return 1;
        if(medidas == Medidas.P ) return 2;
        if(medidas == Medidas.M ) return 3;
        if(medidas == Medidas.G ) return 4;
        if(medidas == Medidas.GG) return 5;

        return 3;
    }
}
