package com.example.camisaloja.dao;

import com.example.camisaloja.model.Compra;
import com.example.camisaloja.model.DetalheCompra;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CompraDao extends DaoPostgres implements Dao<Compra>{
    @Override
    public List<Compra> listar() throws Exception {
        String sql = "select * from compra order by codcompra";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ResultSet rs = ps.executeQuery();

        CamisaDao camisaDao = new CamisaDao();
        FornecedorDao fornecedorDao = new FornecedorDao();

        List<Compra> compras = new ArrayList<Compra>();
        while (rs.next()) {
            Compra compra = new Compra();
            compra.setCodCompra(rs.getLong("codcompra"));
            compra.setDataCompra(rs.getDate("datacompra").toLocalDate());
            compra.setCamisaa(camisaDao.getCamisaById(rs.getLong("idcamisa")));
            compra.setFornecedorr(fornecedorDao.getFornecedorById(rs.getLong("idfornecedor")));

            compras.add(compra);
        }
        return compras;
    }

    @Override
    public void gravar(Compra value) throws Exception {
        String sql = "INSERT INTO compra (datacompra, idcamisa, idfornecedor) VALUES (?,?,?)";
        PreparedStatement ps = getPreparedStatement(sql, true);

        ps.setDate(1, Date.valueOf(value.getDataCompra()));
        ps.setLong(2, value.getCamisaa().getCodigo());
        ps.setLong(3, value.getFornecedorr().getCodFornecedor());

        ps.executeUpdate();
        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        value.setCodCompra(rs.getLong(1));


        // DETALHE COMPRA:
        sql = "INSERT INTO detalhecompra (precototal, quantidade, idcompra, idcamisa) VALUES (?,?,?,?)";
        ps = getPreparedStatement(sql, false);
        ps.setDouble(1, value.getDetalheCompra().getPrecoTotal());
        ps.setDouble(2, value.getDetalheCompra().getQuantidade());
        ps.setLong(3, value.getCodCompra());
        ps.setLong(4, value.getCamisaa().getCodigo());
        ps.executeUpdate();

        //Comprando:
        value.getCamisaa().maisQtdEstoque(value.getDetalheCompra().getQuantidade());
        CamisaDao camisaDao = new CamisaDao();
        camisaDao.attEstoque(value.getCamisaa());

    }

    @Override
    public void alterar(Compra value) throws Exception {
        String sql = "update compra set datacompra = ?, idcamisa = ?, idfornecedor = ? where codcompra = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);

        ps.setDate(1, Date.valueOf(value.getDataCompra()));
        ps.setLong(2, value.getCamisaa().getCodigo());
        ps.setLong(3, value.getFornecedorr().getCodFornecedor());

        ps.executeUpdate();
    }

    @Override
    public void excluir(Compra value) throws Exception {
        String sql = "delete from cliente where codcompra = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, value.getCodCompra());
        ps.executeUpdate();
    }
}


