package com.example.camisaloja.dao;

import com.example.camisaloja.model.Fornecedor;
import com.example.camisaloja.model.Timee;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FornecedorDao extends DaoPostgres implements Dao<Fornecedor>{

    @Override
    public List<Fornecedor> listar() throws Exception {
        String sql = "select * from fornecedor order by codfornecedor";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ResultSet rs = ps.executeQuery();



        List<Fornecedor> fornecedores = new ArrayList<>();
        while (rs.next()) {
            Fornecedor fornecedor = new Fornecedor();
            fornecedor.setNome(rs.getString("nome"));
            fornecedor.setCpnj(rs.getString("cnpj"));
            fornecedor.setCodFornecedor(rs.getLong("codfornecedor"));
            fornecedores.add(fornecedor);
        }

        return fornecedores;
    }

    @Override
    public void gravar(Fornecedor value) throws Exception {
        String sql = "INSERT INTO fornecedor (nome, cnpj) VALUES (?,?)";
        PreparedStatement ps = getPreparedStatement(sql, true);
        ps.setString(1, value.getNome());
        ps.setString(2, value.getCpnj());

        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        value.setCodFornecedor(rs.getLong("codfornecedor"));

    }

    @Override
    public void alterar(Fornecedor value) throws Exception {
        String sql = "update fornecedor set nome = ?, cnpj = ? where codfornecedor = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setString(1, value.getNome());
        ps.setString(2, value.getCpnj());
        ps.setLong(3, value.getCodFornecedor());
        ps.executeUpdate();
    }

    @Override
    public void excluir(Fornecedor value) throws Exception {
        String sql = "delete from fornecedor where codfornecedor = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, value.getCodFornecedor());
        ps.executeUpdate();
    }

    public Fornecedor getFornecedorById(Long id) throws Exception {
        String sql = "select * from fornecedor where codfornecedor = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, id);
        //ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setCodFornecedor(id);
        fornecedor.setNome(rs.getString("nome"));
        fornecedor.setCpnj(rs.getString("cnpj"));
        return fornecedor;
    }
}


