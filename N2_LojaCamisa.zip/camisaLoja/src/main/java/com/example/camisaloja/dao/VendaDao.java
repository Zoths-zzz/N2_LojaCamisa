package com.example.camisaloja.dao;

import com.example.camisaloja.model.Venda;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class VendaDao extends DaoPostgres implements Dao<Venda>{
    @Override
    public List<Venda> listar() throws Exception {
        String sql = "select * from venda order by codvenda";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ResultSet rs = ps.executeQuery();

        CamisaDao camisaDao = new CamisaDao();
        ClienteDao clienteDao = new ClienteDao();

        List<Venda> vendas = new ArrayList<Venda>();
        while (rs.next()) {
            Venda venda = new Venda();
            venda.setCodVenda(rs.getLong("codvenda"));
            venda.setDataVenda(rs.getDate("datavenda").toLocalDate());
            venda.setCamisaa(camisaDao.getCamisaById(rs.getLong("idcamisa")));
            venda.setClientee(clienteDao.getClienteById(rs.getLong("idcliente")));

            vendas.add(venda);
        }

        return vendas;
    }

    @Override
    public void gravar(Venda value) throws Exception {
        String sql = "INSERT INTO venda (datavenda, idcamisa, idcliente) VALUES (?,?,?)";
        PreparedStatement ps = getPreparedStatement(sql, true);

        ps.setDate(1, Date.valueOf(value.getDataVenda()));
        ps.setLong(2, value.getCamisaa().getCodigo());
        ps.setLong(3, value.getClientee().getCodCliente());

        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        value.setCodVenda(rs.getLong(1));

        // DETALHE VENDA:
        sql = "INSERT INTO detalhevenda (precototal, quantidade, idvenda, idcamisa) VALUES (?,?,?,?)";
        ps = getPreparedStatement(sql, false);
        ps.setDouble(1, value.getDetalheVenda().getPrecoTotal());
        ps.setDouble(2, value.getDetalheVenda().getQuantidade());
        ps.setLong(3, value.getCodVenda());
        ps.setLong(4, value.getCamisaa().getCodigo());
        ps.executeUpdate();

        //Vendendo:
        value.getCamisaa().menosQtdEstoque(value.getDetalheVenda().getQuantidade());
        CamisaDao camisaDao = new CamisaDao();
        camisaDao.attEstoque(value.getCamisaa());

    }

    @Override
    public void alterar(Venda value) throws Exception {
        String sql = "update venda set codvenda = ?, datavenda = ? where codvenda = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, value.getCodVenda());
        ps.setDate(2, Date.valueOf(value.getDataVenda()));
        //Fazer o de dataVenda
        ps.executeUpdate();
    }

    @Override
    public void excluir(Venda value) throws Exception {
        String sql = "delete from venda where codvenda = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, value.getCodVenda());
        ps.executeUpdate();
    }
}