package com.example.camisaloja.model;

public class Camisa {
    private Long codigo;
    private Double qtdEstoque = 0.0;
    private Double preco;
    private String ano;
    private Medidas medida;
    private Timee timao;

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Double getQtdEstoque() {
        return qtdEstoque;
    }

    public void setQtdEstoque(Double qtdEstoque) {
        this.qtdEstoque = qtdEstoque;
    }

    public void maisQtdEstoque(Double qtdEstoque){
        this.qtdEstoque += qtdEstoque;
    }

    public void menosQtdEstoque(Double qtdEstoque){
        this.qtdEstoque -= qtdEstoque;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public Medidas getMedida() {
        return medida;
    }

    public void setMedida(Medidas medida) {
        this.medida = medida;
    }

    public Timee getTimao() {
        return timao;
    }

    public void setTimao(Timee timao) {
        this.timao = timao;
    }

    @Override
    public String toString() {
        return this.codigo + ":" + this.ano + "," + this.timao + "," + this.medida;
    }

}
