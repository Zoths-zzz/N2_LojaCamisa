package com.example.camisaloja.model;

import java.time.LocalDate;

public class Venda {
    private Long codVenda;
    private LocalDate dataVenda;
    private Camisa camisaa;
    private Cliente clientee;

    private DetalheVenda detalheVenda;

    public Long getCodVenda() {
        return codVenda;
    }

    public void setCodVenda(Long codVenda) {
        this.codVenda = codVenda;
    }

    public LocalDate getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(LocalDate dataVenda) {
        this.dataVenda = dataVenda;
    }

    public Camisa getCamisaa() {
        return camisaa;
    }

    public void setCamisaa(Camisa camisaa) {
        this.camisaa = camisaa;
    }

    public Cliente getClientee() {
        return clientee;
    }

    public void setClientee(Cliente clientee) {
        this.clientee = clientee;
    }

    public DetalheVenda getDetalheVenda() {
        return detalheVenda;
    }

    public void setDetalheVenda(DetalheVenda detalheVenda) {
        this.detalheVenda = detalheVenda;
    }

    @Override
    public String toString() {
        return this.codVenda + ":" + this.detalheVenda + "," + this.getCamisaa();
    }
}
