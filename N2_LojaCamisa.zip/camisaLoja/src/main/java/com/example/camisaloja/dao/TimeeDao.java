package com.example.camisaloja.dao;

import com.example.camisaloja.model.Timee;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TimeeDao extends DaoPostgres implements Dao<Timee>{

    @Override
    public List<Timee> listar() throws Exception {
        String sql = "select * from timee order by id";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ResultSet rs = ps.executeQuery();

        List<Timee> timees = new ArrayList<>();
        while (rs.next()) {
            Timee timee = new Timee();
            timee.setNome(rs.getString("nome"));
            timee.setId(rs.getLong("id"));
            timees.add(timee);
        }

        return timees;
    }

    @Override
    public void gravar(Timee value) throws Exception {
        String sql = "INSERT INTO timee (nome) VALUES (?)";
        PreparedStatement ps = getPreparedStatement(sql, true);
        ps.setString(1, value.getNome());

        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        value.setId(rs.getLong("id"));

    }

    @Override
    public void alterar(Timee value) throws Exception {
        String sql = "update timee set nome = ? where id = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setString(1, value.getNome());
        ps.setLong(2, value.getId());
        ps.executeUpdate();
    }

    @Override
    public void excluir(Timee value) throws Exception {
        String sql = "delete from timee where id = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, value.getId());
        ps.executeUpdate();
    }

    public Timee getTimeById(Long id) throws Exception {
        String sql = "select * from timee where id = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, id);
        //ps.executeUpdate();

        ResultSet rs = ps.executeQuery();
        rs.next();
        Timee timee = new Timee();
        timee.setId(id);
        timee.setNome(rs.getString("nome"));
        return timee;
    }
}


