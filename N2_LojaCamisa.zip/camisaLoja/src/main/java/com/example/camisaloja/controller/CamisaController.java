package com.example.camisaloja.controller;

import com.example.camisaloja.dao.CamisaDao;
import com.example.camisaloja.dao.TimeeDao;
import com.example.camisaloja.model.Camisa;
import com.example.camisaloja.model.DetalheCompra;
import com.example.camisaloja.model.Medidas;
import com.example.camisaloja.model.Timee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CamisaController implements Initializable {

    private CamisaDao camisaDao = new CamisaDao();
    private TimeeDao timeeDao = new TimeeDao();

    @FXML
    private ListView<Camisa> LstCamisa;

    @FXML
    private Button BtnInserir;

    @FXML
    private Button BtnGravar;

    @FXML
    private Button BtnCancelar;

    @FXML
    private TextField TxtCodigo;

    @FXML
    private TextField TxtQuantidade;

    @FXML
    private ComboBox<Timee> CboTime;

    @FXML
    private TextField TxtPreco;

    @FXML
    private TextField TxtAno;

    @FXML
    private ComboBox<Medidas> CboMedida;


    //= Métodos auxiliares =//

    private void habilitarInterface(boolean valor){
        CboTime.setDisable(!valor);
        TxtPreco.setDisable(!valor);
        TxtAno.setDisable(!valor);
        CboMedida.setDisable(!valor);

        BtnInserir.setDisable(valor);
        BtnCancelar.setDisable(!valor);
        BtnGravar.setDisable(!valor);
        LstCamisa.setDisable(valor);
    }

    private void limparInterface(){
        TxtCodigo.setText("");
        TxtQuantidade.setText("");
        CboTime.setValue(null);
        TxtPreco.setText("");
        TxtAno.setText("");
        CboMedida.setValue(null);
    }

    private void atualizarLista(){
        List<Camisa> camisas;
        try{
            camisas = camisaDao.listar();
        } catch(Exception e) {
            camisas = new ArrayList<Camisa>();
            e.printStackTrace();
        }
        ObservableList<Camisa> camisasOb = FXCollections.observableArrayList(camisas);
        LstCamisa.setItems(camisasOb);
    }

    //= Metodos Lst e Cliente =//

    private void exibirCamisas(){
        Camisa camisass = LstCamisa.getSelectionModel().getSelectedItem();
        if (camisass == null) return;

        TxtCodigo.setText(camisass.getCodigo().toString());
        TxtQuantidade.setText(camisass.getQtdEstoque().toString());
        CboTime.setValue(camisass.getTimao());
        TxtPreco.setText(camisass.getPreco().toString());
        TxtAno.setText(camisass.getAno());
        CboMedida.setValue(camisass.getMedida());
    }

    @FXML
    private void LstCamisa_MouseClicked(MouseEvent evento){
        exibirCamisas();
    }

    @FXML
    private void LstCamisa_KeyPressed(KeyEvent evento){ exibirCamisas(); }

    //= Botões =//

    @FXML
    protected void BtnInserir_Action(ActionEvent evento){
        TxtQuantidade.requestFocus();
        habilitarInterface(true);
        limparInterface();
    }

    @FXML
    protected void BtnCancelar_Action(ActionEvent evento){
        limparInterface();
        habilitarInterface(false);
    }

    @FXML
    protected void BtnGravar_Action(ActionEvent evento){
        Camisa camisa = new Camisa();

        camisa.setTimao(CboTime.getValue());
        camisa.setPreco(Double.parseDouble(TxtPreco.getText()));
        camisa.setAno(TxtAno.getText());
        camisa.setMedida(CboMedida.getValue());
        camisa.setQtdEstoque(0.0);

        try {
            camisaDao.gravar(camisa);
        } catch (Exception e){
            e.printStackTrace();
        }
        atualizarLista();
        habilitarInterface(false);
    }

    //---//
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        atualizarLista();

        //- teste -//
        List<Timee> timees = new ArrayList<Timee>();

        try {
            timees = timeeDao.listar();
        } catch (Exception e) {
           timees = new ArrayList<Timee>();
        }

        ObservableList<Timee> timeesOb = FXCollections.observableArrayList(timees);
        CboTime.setItems(timeesOb);

        CboMedida.getItems().setAll(Medidas.values());
    }

    public void CboTime_Action(ActionEvent actionEvent) {
    }

    public void CboMedida_Action(ActionEvent actionEvent) {
    }
}
