package com.example.camisaloja.model;

public class DetalheCompra {
    private Double precoTotal;
    private Double quantidade;

    private Camisa camisa;

    public Double getPrecoTotal() {
        return precoTotal;
    }

    public void setPrecoTotal(Double precoTotal) {
        this.precoTotal = precoTotal;
    }

    public Double getQuantidade() { return quantidade; }

    public void setQuantidade(Double quantidade) {
        this.quantidade = quantidade;
    }

    public Camisa getCamisa() {
        return camisa;
    }

    public void setCamisa(Camisa camisa) {
        this.camisa = camisa;
    }
}
