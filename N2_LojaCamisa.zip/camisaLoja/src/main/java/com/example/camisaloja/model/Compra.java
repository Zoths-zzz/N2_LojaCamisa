package com.example.camisaloja.model;

import java.time.LocalDate;

public class Compra {
    private Long codCompra;
    private LocalDate dataCompra;
    private Camisa camisaa;
    private Fornecedor fornecedorr;

    private DetalheCompra detalheCompra;

    public Long getCodCompra() {
        return codCompra;
    }

    public void setCodCompra(Long codCompra) {
        this.codCompra = codCompra;
    }

    public LocalDate getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(LocalDate dataCompra) {
        this.dataCompra = dataCompra;
    }

    public Camisa getCamisaa() {
        return camisaa;
    }

    public void setCamisaa(Camisa camisaa) {
        this.camisaa = camisaa;
    }

    public Fornecedor getFornecedorr() {
        return fornecedorr;
    }

    public void setFornecedorr(Fornecedor fornecedorr) {
        this.fornecedorr = fornecedorr;
    }

    public DetalheCompra getDetalheCompra() {
        return detalheCompra;
    }

    public void setDetalheCompra(DetalheCompra detalheCompra) {
        this.detalheCompra = detalheCompra;
    }

    @Override
    public String toString() {
        return this.codCompra + ":" + this.detalheCompra + "," + this.getCamisaa();
    }

}
