package com.example.camisaloja.dao;

import com.example.camisaloja.model.Cliente;
import com.example.camisaloja.model.Fornecedor;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDao extends DaoPostgres implements Dao<Cliente>{

    @Override
    public List<Cliente> listar() throws Exception {
        String sql = "select * from cliente order by codcliente";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ResultSet rs = ps.executeQuery();

        List<Cliente> clientes = new ArrayList<Cliente>();
        while (rs.next()) {
            Cliente cliente = new Cliente();
            cliente.setNome(rs.getString("nome"));
            cliente.setCpf(rs.getString("cpf"));
            cliente.setCodCliente(rs.getLong("codcliente"));
            clientes.add(cliente);
        }

        return clientes;
    }

    @Override
    public void gravar(Cliente value) throws Exception {
        String sql = "INSERT INTO cliente (nome, cpf) VALUES (?,?)";
        PreparedStatement ps = getPreparedStatement(sql, true);
        ps.setString(1, value.getNome());
        ps.setString(2, value.getCpf());

        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        value.setCodCliente(rs.getLong("codcliente"));

    }

    @Override
    public void alterar(Cliente value) throws Exception {
        String sql = "update cliente set nome = ?, cpf = ? where codcliente = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setString(1, value.getNome());
        ps.setString(2, value.getCpf());
        ps.setLong(3, value.getCodCliente());
        ps.executeUpdate();
    }

    @Override
    public void excluir(Cliente value) throws Exception {
        String sql = "delete from cliente where codcliente = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, value.getCodCliente());
        ps.executeUpdate();
    }

    public Cliente getClienteById(Long id) throws Exception {
        String sql = "select * from cliente where codcliente = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, id);
        //ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        Cliente cliente = new Cliente();
        cliente.setCodCliente(id);
        cliente.setNome(rs.getString("nome"));
        cliente.setCpf(rs.getString("cpf"));
        return cliente;
    }
}

