package com.example.camisaloja.model;

public class Fornecedor {
    private String nome;
    private Long codFornecedor;
    private String cpnj;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getCodFornecedor() {
        return codFornecedor;
    }

    public void setCodFornecedor(Long codFornecedor) {
        this.codFornecedor = codFornecedor;
    }

    public String getCpnj() {
        return cpnj;
    }

    public void setCpnj(String cpnj) {
        this.cpnj = cpnj;
    }

    @Override
    public String toString() {
        return this.codFornecedor + ":" + this.nome;
    }
}
