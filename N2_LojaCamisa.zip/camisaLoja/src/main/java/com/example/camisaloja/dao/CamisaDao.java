package com.example.camisaloja.dao;

import com.example.camisaloja.model.Camisa;
import com.example.camisaloja.model.Medidas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CamisaDao extends DaoPostgres implements Dao<Camisa>{
    @Override
    public List<Camisa> listar() throws Exception {
        String sql = "select * from camisa order by codigo";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ResultSet rs = ps.executeQuery();

        TimeeDao timeeDao = new TimeeDao();

        List<Camisa> camisas = new ArrayList<Camisa>();
        while (rs.next()){
            Camisa camisa = new Camisa();

            camisa.setCodigo(rs.getLong("codigo"));
            camisa.setQtdEstoque(rs.getDouble("qtdestoque"));
            camisa.setPreco(rs.getDouble("preco"));
            camisa.setAno(rs.getString("ano"));
            camisa.setTimao(timeeDao.getTimeById(rs.getLong("idtime")));
            camisa.setMedida(Medidas.getMedidaById(rs.getInt("idmedida")));

            camisas.add(camisa);
        }
        return camisas;
    }

    @Override
    public void gravar(Camisa value) throws Exception {
        String sql = "INSERT INTO camisa (preco, ano, idtime, idmedida, qtdestoque) VALUES (?,?,?,?,?)";
        PreparedStatement ps = getPreparedStatement(sql, true);

        ps.setDouble(1, value.getPreco());
        ps.setString(2, value.getAno());
        ps.setLong(3, value.getTimao().getId());
        ps.setInt(4, Medidas.GetIdByMedida(value.getMedida()));
        ps.setDouble(5, value.getQtdEstoque());

        ps.executeUpdate();
        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        value.setCodigo(rs.getLong(1));
    }

    @Override
    public void alterar(Camisa value) throws Exception {
        String sql = "update camisa set preco = ?, ano = ?, idtime = ?, idmedida = ?, qtdestoque = ? where codigo = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);

        ps.setDouble(1, value.getPreco());
        ps.setString(2, value.getAno());
        ps.setLong(3, value.getTimao().getId());
        ps.setInt(4, Medidas.GetIdByMedida(value.getMedida()));
        ps.setDouble(5, value.getQtdEstoque());
        ps.executeUpdate();
    }

    @Override
    public void excluir(Camisa value) throws Exception {
        String sql = "delete from camisa where codigo = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, value.getCodigo());
        ps.executeUpdate();

    }

    public Camisa getCamisaById(Long id) throws Exception {
        String sql = "select * from camisa where codigo = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setLong(1, id);
        //ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        Camisa camisa = new Camisa();

        TimeeDao timeeDao = new TimeeDao();

        camisa.setCodigo(id);
        camisa.setPreco(rs.getDouble("preco"));
        camisa.setAno(rs.getString("ano"));
        camisa.setQtdEstoque(rs.getDouble("qtdestoque"));
        camisa.setTimao(timeeDao.getTimeById(rs.getLong("idtime")));
        camisa.setMedida(Medidas.getMedidaById(rs.getInt("idmedida")));
        return camisa;
    }

    public void attEstoque(Camisa value) throws Exception{
        String sql = "update camsia set qtdestoque = ? where codigo = ?";
        PreparedStatement ps = getPreparedStatement(sql, false);
        ps.setDouble(1, value.getQtdEstoque());
        ps.setLong(2, value.getCodigo());

    }
}
